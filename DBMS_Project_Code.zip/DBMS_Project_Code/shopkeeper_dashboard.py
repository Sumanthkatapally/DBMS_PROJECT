from tkinter import Tk, Label, Button, Entry, ttk, messagebox, Toplevel
from db_connection import connect_to_db

def open_shopkeeper_dashboard(shopkeeper_id, open_login_window):
    # Create the shopkeeper dashboard window
    dashboard = Tk()
    dashboard.title("Shopkeeper Dashboard")
    dashboard.geometry("800x500")

    # Function to display all products
    def view_products():
        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            query = """
                SELECT productID, productName, Size, PricePerUnit, QuantityInStock
                FROM PRODUCT
            """
            cursor.execute(query)
            rows = cursor.fetchall()
            conn.close()

            for item in product_tree.get_children():
                product_tree.delete(item)

            for row in rows:
                product_tree.insert('', 'end', values=row)
        except Exception as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    # Function to search products by name
    def search_products():
        product_name = search_entry.get().strip()
        if not product_name:
            messagebox.showwarning("Input Error", "Please enter a product name to search.")
            return

        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            query = """
                SELECT productID, productName, Size, PricePerUnit, QuantityInStock
                FROM PRODUCT
                WHERE productName LIKE %s
            """
            cursor.execute(query, (f"%{product_name}%",))
            rows = cursor.fetchall()
            conn.close()

            for item in product_tree.get_children():
                product_tree.delete(item)

            if rows:
                for row in rows:
                    product_tree.insert('', 'end', values=row)
            else:
                messagebox.showinfo("No Results", "No products found with the given name.")
        except Exception as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    # Function to handle payment details
    def open_payment_popup(product_id, quantity, amount, shopkeeper_id):
        # Create a new modal dialog
        payment_popup = Toplevel(dashboard)
        payment_popup.title("Payment Details")
        payment_popup.geometry("400x300")
        payment_popup.grab_set()  # Make the window modal

        Label(payment_popup, text="Enter Payment Details", font=("Arial", 16)).pack(pady=10)

        Label(payment_popup, text="Card Number:").pack(pady=5)
        card_number_entry = Entry(payment_popup, width=30)
        card_number_entry.pack(pady=5)

        Label(payment_popup, text="Expiration Date (MM/YY):").pack(pady=5)
        expiration_entry = Entry(payment_popup, width=30)
        expiration_entry.pack(pady=5)

        Label(payment_popup, text="CVV:").pack(pady=5)
        cvv_entry = Entry(payment_popup, show="*", width=10)
        cvv_entry.pack(pady=5)

        def process_payment():
            card_number = card_number_entry.get().strip()
            expiration = expiration_entry.get().strip()
            cvv = cvv_entry.get().strip()

            if not card_number or not expiration or not cvv:
                messagebox.showwarning("Input Error", "Please fill all payment details.")
                return

            try:
                # Simulate payment processing
                messagebox.showinfo("Payment Success", "Payment has been processed successfully!")

                # Insert the order into the database after successful payment
                conn = connect_to_db()
                cursor = conn.cursor()
                insert_query = """
                    INSERT INTO `ORDER` (OrderDate, Quantity, OrderStatus, Amount, ShopkeeperId, ProductID)
                    VALUES (CURDATE(), %s, 'Pending', %s, %s, %s)
                """
                cursor.execute(insert_query, (quantity, amount, shopkeeper_id, product_id))
                conn.commit()
                conn.close()

                # Refresh orders view and close the payment popup
                view_orders()
                payment_popup.destroy()

            except Exception as err:
                messagebox.showerror("Database Error", f"Error: {err}")

        Button(payment_popup, text="Submit Payment", command=process_payment).pack(pady=20)

    # Function to place an order
    def place_order():
        try:
            product_id = product_id_entry.get()
            quantity = quantity_entry.get()

            if not product_id or not quantity:
                messagebox.showwarning("Input Error", "Please enter both product ID and quantity.")
                return

            conn = connect_to_db()
            cursor = conn.cursor()

            # Fetch the product's price for the given product ID
            cursor.execute("SELECT PricePerUnit FROM PRODUCT WHERE ProductID = %s", (product_id,))
            result = cursor.fetchone()
            conn.close()

            if not result:
                messagebox.showwarning("Error", "Product not found.")
                return

            price_per_unit = result[0]
            total_amount = float(price_per_unit) * int(quantity)

            # Open the payment pop-up, passing product and payment details
            open_payment_popup(product_id, quantity, total_amount, shopkeeper_id)

        except Exception as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    # Function to view orders
    def view_orders():
        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            query = """
                SELECT OrderId, OrderDate, Quantity, OrderStatus, Amount
                FROM `ORDER`
                WHERE ShopkeeperId = %s
            """
            cursor.execute(query, (shopkeeper_id,))
            rows = cursor.fetchall()
            conn.close()

            for item in order_tree.get_children():
                order_tree.delete(item)

            for row in rows:
                order_tree.insert('', 'end', values=row)
        except Exception as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    # Dashboard UI
    Label(dashboard, text="Shopkeeper Dashboard", font=("Arial", 20)).pack(pady=10)

    # Product Management
    product_frame = ttk.LabelFrame(dashboard, text="View Products")
    product_frame.pack(fill="x", padx=10, pady=10)

    # Search Bar
    search_frame = ttk.Frame(product_frame)
    search_frame.pack(fill="x", pady=5)

    Label(search_frame, text="Search Product:").pack(side="left", padx=5)
    search_entry = Entry(search_frame, width=30)
    search_entry.pack(side="left", padx=5)
    Button(search_frame, text="Search", command=search_products).pack(side="left", padx=5)
    Button(search_frame, text="Show All", command=view_products).pack(side="left", padx=5)

    # Product Treeview
    product_tree = ttk.Treeview(product_frame, columns=("ID", "Name", "Size", "Price", "Stock"), show="headings")
    product_tree.heading("ID", text="Product ID")
    product_tree.heading("Name", text="Name")
    product_tree.heading("Size", text="Size")
    product_tree.heading("Price", text="Price/Unit")
    product_tree.heading("Stock", text="Stock")
    product_tree.pack(fill="x")

    # Place Order
    order_frame = ttk.LabelFrame(dashboard, text="Place Order")
    order_frame.pack(fill="x", padx=10, pady=10)

    Label(order_frame, text="Product ID:").grid(row=0, column=0, padx=5, pady=5)
    product_id_entry = Entry(order_frame)
    product_id_entry.grid(row=0, column=1, padx=5, pady=5)

    Label(order_frame, text="Quantity:").grid(row=1, column=0, padx=5, pady=5)
    quantity_entry = Entry(order_frame)
    quantity_entry.grid(row=1, column=1, padx=5, pady=5)

    Button(order_frame, text="Place Order", command=place_order).grid(row=2, column=0, columnspan=2, pady=10)

    # View Orders
    order_view_frame = ttk.LabelFrame(dashboard, text="Your Orders")
    order_view_frame.pack(fill="x", padx=10, pady=10)
    order_tree = ttk.Treeview(order_view_frame, columns=("ID", "Date", "Quantity", "Status", "Amount"), show="headings")
    order_tree.heading("ID", text="Order ID")
    order_tree.heading("Date", text="Order Date")
    order_tree.heading("Quantity", text="Quantity")
    order_tree.heading("Status", text="Status")
    order_tree.heading("Amount", text="Amount")
    order_tree.pack(fill="x")
    Button(order_view_frame, text="Refresh Orders", command=view_orders).pack(pady=5)

    # Logout Functionality
    def logout():
        dashboard.destroy()
        open_login_window()  # Go back to login screen

    # Place the logout button at the top-right corner using place() method
    logout_button = Button(dashboard, text="Logout", command=logout)
    logout_button.place(relx=0.95, rely=0.05, anchor="ne")  # Top-right corner

    # Initial View
    view_products()  # Load all products initially

    dashboard.mainloop()  # Start the event loop
