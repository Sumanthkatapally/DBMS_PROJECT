from tkinter import Tk, Label, Entry, Button, messagebox
from db_connection import connect_to_db

def manage_shopkeepers():
    window = Tk()
    window.title("Manage Shopkeepers")
    window.geometry("400x300")

    Label(window, text="Add Shopkeeper", font=("Arial", 14)).pack(pady=10)

    Label(window, text="Username:").pack(pady=5)
    username_entry = Entry(window)
    username_entry.pack(pady=5)

    Label(window, text="Password:").pack(pady=5)
    password_entry = Entry(window, show="*")
    password_entry.pack(pady=5)

    def add_shopkeeper():
        username = username_entry.get()
        password = password_entry.get()

        if not username or not password:
            messagebox.showwarning("Input Error", "Please fill in all fields.")
            return

        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO SHOPKEEPER (Username, Password) VALUES (%s, %s)", (username, password))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Shopkeeper added successfully!")
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    Button(window, text="Add Shopkeeper", command=add_shopkeeper).pack(pady=10)

    window.mainloop()
