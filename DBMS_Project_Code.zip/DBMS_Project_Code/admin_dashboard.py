# admin_dashboard.py
from tkinter import Tk, Label, Button, messagebox, Entry, ttk
from db_connection import connect_to_db
import mysql.connector

def open_admin_dashboard(open_login_window):
    # Create the admin dashboard window
    admin_dashboard = Tk()
    admin_dashboard.title("Admin Dashboard")
    #admin_dashboard.geometry("800x600")
    admin_dashboard.state("zoomed")  # Open the window in maximized state

    Label(admin_dashboard, text="Admin Dashboard", font=("Arial", 20)).pack(pady=10)

    # Frame for Manage Orders and Manage Products buttons
    manage_frame = ttk.Frame(admin_dashboard)
    manage_frame.pack(pady=20)

    # ------------------------------- Frames for Sections -------------------------------
    manage_orders_frame = ttk.Frame(admin_dashboard)
    manage_products_frame = ttk.Frame(admin_dashboard)

    # ------------------------------- Show/Hide Functions -------------------------------
    def show_manage_products():
        # Hide the Manage Orders section
        manage_orders_frame.pack_forget()
        # Show the Manage Products section
        manage_products_frame.pack(fill="both", padx=10, pady=10)

    def show_manage_orders():
        # Hide the Manage Products section
        manage_products_frame.pack_forget()
        # Show the Manage Orders section
        manage_orders_frame.pack(fill="both", padx=10, pady=10)

    # ------------------------------- Buttons to Switch Sections -------------------------------
    manage_orders_button = Button(manage_frame, text="Manage Orders", command=show_manage_orders)
    manage_orders_button.pack(side="left", padx=20)

    manage_products_button = Button(manage_frame, text="Manage Products", command=show_manage_products)
    manage_products_button.pack(side="left", padx=20)

    # ------------------------------- Manage Orders Section -------------------------------
    def view_pending_orders():
        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT OrderID, OrderDate, ShopkeeperID, Quantity, Amount 
                FROM `ORDER` 
                WHERE OrderStatus = 'Pending'
            """)
            rows = cursor.fetchall()
            conn.close()

            for item in orders_tree.get_children():
                orders_tree.delete(item)

            for row in rows:
                orders_tree.insert('', 'end', values=row)
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    # Function to approve the selected order
    def approve_order():
        selected_item = orders_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select an order to approve.")
            return

        order_id = orders_tree.item(selected_item)['values'][0]
        try:
            conn = connect_to_db()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT ProductID, Quantity 
                FROM `ORDER` 
                WHERE OrderID = %s
            """, (order_id,))
            order_details = cursor.fetchone()

            if order_details:
                product_id = order_details[0]
                quantity = order_details[1]

                cursor.execute("""
                    UPDATE `ORDER` 
                    SET OrderStatus = 'Shipped' 
                    WHERE OrderID = %s
                """, (order_id,))
                conn.commit()

                cursor.execute("""
                    UPDATE PRODUCT
                    SET QuantityInStock = QuantityInStock - %s
                    WHERE ProductID = %s
                """, (quantity, product_id))
                conn.commit()

                conn.close()
                messagebox.showinfo("Success", "Order approved and product quantity updated!")
                view_pending_orders()
            else:
                messagebox.showwarning("Error", "Order not found.")
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    orders_tree = ttk.Treeview(manage_orders_frame, columns=("Order ID", "Order Date", "Shopkeeper ID", "Quantity", "Amount"), show="headings")
    orders_tree.heading("Order ID", text="Order ID")
    orders_tree.heading("Order Date", text="Order Date")
    orders_tree.heading("Shopkeeper ID", text="Shopkeeper ID")
    orders_tree.heading("Quantity", text="Quantity")
    orders_tree.heading("Amount", text="Amount")
    orders_tree.pack(fill="x")

    Button(manage_orders_frame, text="View Pending Orders", command=view_pending_orders).pack(pady=5)
    Button(manage_orders_frame, text="Approve Order", command=approve_order).pack(pady=5)

    # ------------------------------- Manage Products Section -------------------------------
    def view_products():
        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT ProductID, ProductName, CategoryId, Size, PricePerUnit, QuantityInStock 
                FROM PRODUCT
            """)
            rows = cursor.fetchall()
            conn.close()

            for item in product_tree.get_children():
                product_tree.delete(item)

            for row in rows:
                product_tree.insert('', 'end', values=row)
        except Exception as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    def add_product():
        name = product_name_entry.get()
        category_id = category_id_entry.get()
        size = size_entry.get()
        price = price_per_unit_entry.get()
        quantity = quantity_in_stock_entry.get()

        if not name or not category_id or not size or not price or not quantity:
            messagebox.showwarning("Input Error", "All fields are required.")
            return

        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO PRODUCT (ProductName, CategoryId, Size, PricePerUnit, QuantityInStock)
                VALUES (%s, %s, %s, %s, %s)
            """, (name, category_id, size, price, quantity))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Product added successfully!")
            view_products()  # Refresh the product list
        except Exception as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    def update_product():
        selected_item = product_tree.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a product to update.")
            return

        product_id = product_tree.item(selected_item)['values'][0]
        name = product_name_entry.get()
        category_id = category_id_entry.get()
        size = size_entry.get()
        price = price_per_unit_entry.get()
        quantity = quantity_in_stock_entry.get()

        if not name or not category_id or not size or not price or not quantity:
            messagebox.showwarning("Input Error", "All fields are required.")
            return

        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE PRODUCT
                SET ProductName = %s, CategoryId = %s, Size = %s, PricePerUnit = %s, QuantityInStock = %s
                WHERE ProductID = %s
            """, (name, category_id, size, price, quantity, product_id))
            conn.commit()
            conn.close()

            messagebox.showinfo("Success", "Product updated successfully!")
            view_products()  # Refresh the product list
        except Exception as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    def clear_fields():
        product_name_entry.delete(0, 'end')
        category_id_entry.delete(0, 'end')
        size_entry.delete(0, 'end')
        price_per_unit_entry.delete(0, 'end')
        quantity_in_stock_entry.delete(0, 'end')

    # UI for managing products
    Label(manage_products_frame, text="Manage Products", font=("Arial", 16)).pack(pady=10)

    form_frame = ttk.Frame(manage_products_frame)
    form_frame.pack(pady=10)

    Label(form_frame, text="Product Name:").grid(row=0, column=0, padx=5, pady=5)
    product_name_entry = Entry(form_frame, width=30)
    product_name_entry.grid(row=0, column=1, padx=5, pady=5)

    Label(form_frame, text="Category ID:").grid(row=1, column=0, padx=5, pady=5)
    category_id_entry = Entry(form_frame, width=30)
    category_id_entry.grid(row=1, column=1, padx=5, pady=5)

    Label(form_frame, text="Size:").grid(row=2, column=0, padx=5, pady=5)
    size_entry = Entry(form_frame, width=30)
    size_entry.grid(row=2, column=1, padx=5, pady=5)

    Label(form_frame, text="Price Per Unit:").grid(row=3, column=0, padx=5, pady=5)
    price_per_unit_entry = Entry(form_frame, width=30)
    price_per_unit_entry.grid(row=3, column=1, padx=5, pady=5)

    Label(form_frame, text="Quantity in Stock:").grid(row=4, column=0, padx=5, pady=5)
    quantity_in_stock_entry = Entry(form_frame, width=30)
    quantity_in_stock_entry.grid(row=4, column=1, padx=5, pady=5)

    Button(form_frame, text="Add Product", command=add_product).grid(row=5, column=0, columnspan=2, pady=10)
    Button(form_frame, text="Update Product", command=update_product).grid(row=6, column=0, columnspan=2, pady=10)
    Button(form_frame, text="Clear Fields", command=clear_fields).grid(row=7, column=0, columnspan=2, pady=10)

    product_tree = ttk.Treeview(manage_products_frame, columns=("Product ID", "Name", "Category", "Size", "Price", "Stock"), show="headings")
    product_tree.heading("Product ID", text="Product ID")
    product_tree.heading("Name", text="Name")
    product_tree.heading("Category", text="Category ID")
    product_tree.heading("Size", text="Size")
    product_tree.heading("Price", text="Price Per Unit")
    product_tree.heading("Stock", text="Quantity in Stock")
    product_tree.pack(fill="x", padx=10, pady=10)

    Button(manage_products_frame, text="View Products", command=view_products).pack(pady=5)

    # Initially hide the frame
    manage_products_frame.pack_forget()

    manage_orders_frame.pack_forget()

    # Logout functionality
    def logout():
        admin_dashboard.destroy()
        open_login_window()

    logout_button = Button(admin_dashboard, text="Logout", command=logout)
    logout_button = Button(admin_dashboard, text="Logout", command=logout)
    logout_button.place(relx=0.95, rely=0.05, anchor="ne")  # Top-right corner


    admin_dashboard.mainloop()
