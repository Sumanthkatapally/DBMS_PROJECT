from tkinter import Tk, Label, Entry, Button, messagebox
from db_connection import connect_to_db

def manage_products():
    window = Tk()
    window.title("Manage Products")
    window.geometry("400x300")

    Label(window, text="Add Product", font=("Arial", 14)).pack(pady=10)

    Label(window, text="Product Name:").pack(pady=5)
    product_name_entry = Entry(window)
    product_name_entry.pack(pady=5)

    Label(window, text="Price Per Unit:").pack(pady=5)
    price_entry = Entry(window)
    price_entry.pack(pady=5)

    def add_product():
        product_name = product_name_entry.get()
        price = price_entry.get()

        if not product_name or not price:
            messagebox.showwarning("Input Error", "Please fill in all fields.")
            return

        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO PRODUCT (ProductName, PricePerUnit) VALUES (%s, %s)", (product_name, price))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Product added successfully!")
        except mysql.connector.Error as err:
            messagebox.showerror("Database Error", f"Error: {err}")

    Button(window, text="Add Product", command=add_product).pack(pady=10)

    window.mainloop()
