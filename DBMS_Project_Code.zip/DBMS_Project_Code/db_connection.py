import mysql.connector

def connect_to_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",  # Replace with your MySQL username
        password="Manju12345",  # Replace with your MySQL password
        database="Warehouse_Management_System_DBMS_Project"
    )
