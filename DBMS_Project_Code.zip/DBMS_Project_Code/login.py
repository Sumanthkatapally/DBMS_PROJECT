# login.py
from tkinter import Tk, Label, Button, Entry, messagebox
from admin_dashboard import open_admin_dashboard
from shopkeeper_dashboard import open_shopkeeper_dashboard
from db_connection import connect_to_db

# Global variable for shopkeeper_id
shopkeeper_id = None

# Admin Login
def admin_login():
    username = username_entry.get()
    password = password_entry.get()

    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = "SELECT AdminID FROM ADMIN WHERE Username = %s AND Password = %s"
        cursor.execute(query, (username, password))
        result = cursor.fetchone()
        conn.close()

        if result:
            messagebox.showinfo("Success", "Admin Login Successful!")
            login_window.destroy()
            open_admin_dashboard(open_login_window)  # Pass the login function
        else:
            messagebox.showerror("Error", "Invalid Admin Credentials!")
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")

# Shopkeeper Login
def shopkeeper_login():
    username = username_entry.get()
    password = password_entry.get()

    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = "SELECT ShopkeeperID FROM SHOPKEEPER WHERE Username = %s AND Password = %s"
        cursor.execute(query, (username, password))
        result = cursor.fetchone()
        conn.close()

        if result:
            global shopkeeper_id
            shopkeeper_id = result[0]
            messagebox.showinfo("Success", "Shopkeeper Login Successful!")
            login_window.destroy()
            open_shopkeeper_dashboard(shopkeeper_id, open_login_window)  # Pass the login function
        else:
            messagebox.showerror("Error", "Invalid Shopkeeper Credentials!")
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")

# Login Window
def open_login_window():
    global username_entry, password_entry, login_window
    login_window = Tk()
    login_window.title("Login")
    login_window.geometry("300x200")

    Label(login_window, text="Username:").pack(pady=5)
    username_entry = Entry(login_window)
    username_entry.pack(pady=5)

    Label(login_window, text="Password:").pack(pady=5)
    password_entry = Entry(login_window, show="*")
    password_entry.pack(pady=5)

    Button(login_window, text="Admin Login", command=admin_login).pack(pady=5)
    Button(login_window, text="Shopkeeper Login", command=shopkeeper_login).pack(pady=5)

    login_window.mainloop()

# Start the Login window
open_login_window()
